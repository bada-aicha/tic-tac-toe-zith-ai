import cv2
import numpy as np

def find_corners(img):
    """Finds Harris corners in the image using adaptive thresholding."""
    # Convert to grayscale if needed
    if len(img.shape) == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    # Apply Gaussian blur
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    
    # Apply adaptive threshold
    thresh = cv2.adaptiveThreshold(
        blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 2)

    # Apply Harris corner detection
    corners = cv2.cornerHarris(thresh, 5, 3, 0.1)
    corners = cv2.dilate(corners, None)
    corners = cv2.threshold(corners, 0.01 * corners.max(), 255, cv2.THRESH_BINARY)[1]
    corners = corners.astype(np.uint8)
    
    # Connected components with stats
    _, labels, stats, centroids = cv2.connectedComponentsWithStats(
        corners, connectivity=4)
    
    return stats

def contoured_bbox(img):
    """Returns bounding box of contoured image using adaptive thresholding."""
    # Convert to grayscale if needed
    if len(img.shape) == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    # Apply Gaussian blur
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    
    # Apply adaptive threshold
    thresh = cv2.adaptiveThreshold(
        blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 2)

    # Find contours
    contours, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    
    # Largest object is whole image, second largest object is the ROI
    sorted_cntr = sorted(contours, key=lambda cntr: cv2.contourArea(cntr))
    return cv2.boundingRect(sorted_cntr[-2])

def preprocess_input(img):
    """Preprocess image to match model's input shape for shape detection."""
    img = cv2.resize(img, (32, 32))
    # Expand for channel_last and batch size, respectively
    img = np.expand_dims(img, axis=-1)
    img = np.expand_dims(img, axis=0)
    return img.astype(np.float32) / 255
