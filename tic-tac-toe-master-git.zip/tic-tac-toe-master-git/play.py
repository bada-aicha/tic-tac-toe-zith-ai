import os
import sys
import cv2
import argparse
import numpy as np
from keras.models import load_model
from utils import imutils, detections
from alphabeta import Tic, get_enemy, determine
import serial
import time

def parse_arguments(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument('cam', type=str, help='USB camera for video streaming')
    parser.add_argument('--model', '-m', type=str, default='data/model.h5', help='model file (.h5) to detect Xs and Os')
    return parser.parse_args()

def find_sheet_paper(frame, add_margin=True):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    thresh = cv2.adaptiveThreshold(blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 2)
    stats = detections.find_corners(thresh)
    corners = stats[1:, :2]
    corners = imutils.order_points(corners)
    paper = imutils.four_point_transform(frame, corners)
    if add_margin:
        paper = paper[10:-10, 10:-10]
    return paper, corners

def find_shape(cell):
    mapper = {0: None, 1: 'X', 2: 'O'}
    cell = detections.preprocess_input(cell)
    prediction = model.predict(cell)
    idx = np.argmax(prediction)
    return mapper[idx]

def get_board_template(thresh):
    middle_center = detections.contoured_bbox(thresh)
    center_x, center_y, width, height = middle_center

    left = center_x - width
    right = center_x + width
    top = center_y - height
    bottom = center_y + height

    middle_left = (left, center_y, width, height)
    middle_right = (right, center_y, width, height)
    top_left = (left, top, width, height)
    top_center = (center_x, top, width, height)
    top_right = (right, top, width, height)
    bottom_left = (left, bottom, width, height)
    bottom_center = (center_x, bottom, width, height)
    bottom_right = (right, bottom, width, height)

    return [top_left, top_center, top_right,
            middle_left, middle_center, middle_right,
            bottom_left, bottom_center, bottom_right]

def draw_shape(template, shape, coords):
    x, y, w, h = coords
    if shape == 'O':
        centroid = (x + int(w / 2), y + int(h / 2))
        radius = max(0, int(w / 2) - 10)
        cv2.circle(template, centroid, radius, (0, 0, 0), 2)
    elif shape == 'X':
        cv2.line(template, (x + 10, y + 10), (x + w - 10, y + h - 10), (0, 0, 0), 2)
        cv2.line(template, (x + 10, y + h - 10), (x + w - 10, y + 10), (0, 0, 0), 2)
    return template
def send_gcode_command(movement, ser):
    gcode_commands = []
    
    if movement == 0:
        gcode_commands = [
            
            "$J=G21G91X0.83F25",
            "$J=G21G91Z-1.85F25",
            "$J=G21G91Y0.33F25",
            "$J=G21G91Y-0.33F25",
            "$J=G21G91Z1.85F25",
            "$J=G21G91X-0.83F25"

        ]
    elif movement == 1:
        gcode_commands = [
            "$J=G21G91X0.99F25",
            "$J=G21G91Z-1.9F25",
            "$J=G21G91Y0.35F25",
            "$J=G21G91Y-0.35F25",
            "$J=G21G91Z1.9F25",
            "$J=G21G91X-0.99F25"
        ]
    elif movement == 2:
        gcode_commands = [
            "$J=G21G91X1.14F25",
            "$J=G21G91Z-2F25",
            "$J=G21G91Y0.492F25",
            "$J=G21G91Y-0.492F25",
            "$J=G21G91Z2F25",
            "$J=G21G91X-1.14F25"
        ]
    elif movement == 3:
        gcode_commands = [
            "$J=G21G91X0.83F25",
            "$J=G21G91Z-1.5F25",
            "$J=G21G91Y0.3F25",
            "$J=G21G91Y-0.3F25",
            "$J=G21G91Z1.5F25",
            "$J=G21G91X-0.83F25"
        ]
    elif movement == 4:
        gcode_commands = [
            "$J=G21G91X0.97F25",
            "$J=G21G91Z-1.50F25",
            "$J=G21G91Y0.35F25",
            "$J=G21G91Y-0.35F25",
            "$J=G21G91Z1.50F25",
            "$J=G21G91X-0.97F25"
            
            ]
    elif movement == 5:
        gcode_commands = [
            "$J=G21G91X1.15F25",
            "$J=G21G91Z-1.63F25",
            "$J=G21G91Y0.39F25",
            "$J=G21G91Y-0.39F25",
            "$J=G21G91Z1.63F25",
            "$J=G21G91X-1.15F25"

        ]
    elif movement == 6:
        gcode_commands = [
           "$J=G21G91X0.80F25",
           "$J=G21G91Z-1.3F25",
           "$J=G21G91Y0.32F25",
           "$J=G21G91Y-0.32F25",
           "$J=G21G91Z1.3F25",
           "$J=G21G91X-0.80F25"

        ]
    elif movement == 7:
        gcode_commands = [
            "$J=G21G91X0.99F25",
            "$J=G21G91Z-1.25F25",
            "$J=G21G91Y0.33F25",
            "$J=G21G91Y-0.33F25",
            "$J=G21G91Z1.25F25",
            "$J=G21G91X-0.99F25"

        ]
    elif movement == 8:
        gcode_commands = [
            "$J=G21G91X1.12F25",
            "$J=G21G91Z-1.3F25",
            "$J=G21G91Y0.35F25",
           "$J=G21G91Y-0.35F25",
            "$J=G21G91Z1.3F25",
            "$J=G21G91X-1.12F25"
        ]

    for command in gcode_commands:
        command += '\n'
        ser.write(command.encode())
        time.sleep(0.1)
def play(vcap):
    serial_port = 'COM10'
    baud_rate = 115200
    ser = serial.Serial(serial_port, baud_rate, timeout=1)
    time.sleep(2)
    board = Tic()
    history = {}
    message = True
    human_player = 'X'
    computer_player = 'O'
    current_player = human_player  # Start with the human player

    while True:
        ret, frame = vcap.read()
        key = cv2.waitKey(1) & 0xFF
        if not ret:
            print('[INFO] finished video processing')
            break

        if key == ord('q'):
            print('[INFO] stopped video processing')
            break

        paper, corners = find_sheet_paper(frame)
        for c in corners:
            cv2.circle(frame, tuple(map(int, c)), 2, (0, 0, 255), 2)

        gray = cv2.cvtColor(paper, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        thresh = cv2.adaptiveThreshold(blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 2)
        grid = get_board_template(thresh)

        for i, (x, y, w, h) in enumerate(grid):
            cv2.rectangle(paper, (x, y), (x + w, y + h), (0, 0, 0), 2)
            if history.get(i) is not None:
                shape = history[i]['shape']
                paper = draw_shape(paper, shape, (x, y, w, h))

        if message:
            print('Make your move, then press spacebar')
            message = False

        cv2.imshow('original', frame)
        cv2.imshow('bird view', paper)

        if key == 32:
            if current_player == human_player:
                # Human player move
                available_moves = np.delete(np.arange(9), list(history.keys()))
                human_made_move = False
                for i, (x, y, w, h) in enumerate(grid):
                    if i not in available_moves:
                        continue
                    cell = thresh[int(y): int(y + h), int(x): int(x + w)]
                    shape = find_shape(cell)
                    if shape == human_player:
                        history[i] = {'shape': shape, 'bbox': (x, y, w, h)}
                        board.make_move(i, human_player)
                        paper = draw_shape(paper, shape, (x, y, w, h))
                        human_made_move = True
                        current_player = computer_player  # Switch to the AI player
                        break

                if not human_made_move:
                    print("No valid move detected. Make your move, then press spacebar.")
                    continue

            if board.complete():
                break

            if current_player == computer_player:
                # Computer move
                computer_move = determine(board, computer_player)
                board.make_move(computer_move, computer_player)
                history[computer_move] = {'shape': computer_player, 'bbox': grid[computer_move]}
                paper = draw_shape(paper, computer_player, grid[computer_move])
                print(f"Computer move: {computer_move}")
                current_player = human_player  # Switch to the human player
                send_gcode_command(computer_move, ser)  # Send the G-code command

            if board.complete():
                break

            message = True

    winner = board.winner()
    height = paper.shape[0]
    text = 'Winner is {}'.format(str(winner))
    cv2.putText(paper, text, (10, height - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
    cv2.imshow('bird view', paper)
    cv2.waitKey(0) & 0xFF

    vcap.release()
    cv2.destroyAllWindows()
    return board.winner()



def main(args):
    global model
    assert os.path.exists(args.model), '{} does not exist'.format(args.model)
    model = load_model(args.model)

    vcap = cv2.VideoCapture(args.cam)
    if not vcap.isOpened():
        raise IOError('could not get feed from cam #{}'.format(args.cam))

    winner = play(vcap)
    print('Winner is:', winner)
    sys.exit()

if __name__ == '__main__':
    main(parse_arguments(sys.argv[1:]))
